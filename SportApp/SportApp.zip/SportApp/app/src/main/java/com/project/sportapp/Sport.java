package com.project.sportapp;

public class Sport {

    private String title;
    private String info;

    Sport(String title, String info) {
        this.title = title;
        this.info = info;
    }
}
